
  # PharmaShe Web App UI Design

  This is a code bundle for PharmaShe Web App UI Design. The original project is available at https://www.figma.com/design/6ESJL6ju1hkxxXSNevMBIe/PharmaShe-Web-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  